
/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./app/**/*.{ts,tsx}", "./components/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        royal: '#1E3A8A',
        emerald: '#10B981',
        gold: '#D4AF37',
        silver: '#9CA3AF',
        ink: '#0B1220',
        panel: '#0F172A',
      },
      boxShadow: { glow: '0 0 24px rgba(16,185,129,0.25)' }
    },
  },
  plugins: [],
}
