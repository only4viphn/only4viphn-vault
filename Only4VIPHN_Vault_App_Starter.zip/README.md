
# Only4VIPHN — The Private Collector’s Vault (Starter)
Royal Blue with an Emerald Spark. Deploy-ready Next.js + Supabase.

## Quick Start (Free)

1) **Create Supabase (Free)** → copy Project URL & anon key → create `.env.local` using `.env.example`.
2) **Run schema** → Supabase SQL Editor → paste `schema.sql` and run.
3) **Deploy to Vercel (Free)** → New Project → import/upload this folder → add env vars → Deploy.
4) Open `/dashboard` and `/`.

CSV: see `import_template.csv`. Images go to Supabase Storage bucket `vault/` (keep originals + 512px thumbs).
