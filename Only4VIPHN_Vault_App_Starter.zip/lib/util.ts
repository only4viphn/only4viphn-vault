export const currency=(n?:number|null)=>{if(n==null||isNaN(n as any))return '—';return n.toLocaleString('en-US',{style:'currency',currency:'USD'});};
