export default { images: { domains: ['*.supabase.co'] } };
