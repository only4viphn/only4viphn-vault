
import './globals.css';
export const metadata = { title: 'Only4VIPHN — The Private Collector’s Vault', description: 'Royal Blue with an Emerald Spark.' };
export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (<html lang="en"><body><div className="max-w-6xl mx-auto p-4 md:p-8">{children}</div></body></html>);
}
