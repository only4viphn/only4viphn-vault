
'use client';
import { useEffect, useState } from 'react'; import { supabase } from '@/lib/supabase'; import { currency } from '@/lib/util'; import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, PieChart, Pie, Cell } from 'recharts'; import Link from 'next/link';
export default function Dashboard(){const [summary,setSummary]=useState<any>(null); const [byCategory,setByCategory]=useState<any[]>([]);
  useEffect(()=>{(async()=>{const {data:s}=await supabase.rpc('vault_summary'); const {data:c}=await supabase.from('category_summary').select('*'); setSummary(s); setByCategory(c||[]);})();},[]);
  return (<div><Link href="/" className="text-silver/70 hover:text-silver">← Home</Link><h1 className="text-2xl font-semibold text-gold mt-2">Vault Dashboard</h1>
    <div className="grid md:grid-cols-4 gap-4 mt-3"><div className="card p-4"><div className="text-silver/70 text-sm">Total Items</div><div className="kpi">{summary?.total_items||0}</div></div>
    <div className="card p-4"><div className="text-silver/70 text-sm">Total Invested</div><div className="kpi">{currency(summary?.total_invested||0)}</div></div>
    <div className="card p-4"><div className="text-silver/70 text-sm">Total Market Value</div><div className="kpi">{currency(summary?.total_value||0)}</div></div>
    <div className="card p-4"><div className="text-silver/70 text-sm">Total Profit</div><div className="kpi">{currency((summary?.total_value||0)-(summary?.total_invested||0))}</div></div></div>
    <div className="grid md:grid-cols-2 gap-4 mt-4">
      <div className="card p-4"><div className="mb-2 font-medium">Value by Category</div><div className="h-64"><ResponsiveContainer width="100%" height="100%">
        <BarChart data={byCategory}><XAxis dataKey="category" stroke="#9CA3AF"/><YAxis stroke="#9CA3AF"/><Tooltip/><Bar dataKey="total_value" fill="#1E3A8A"/></BarChart>
      </ResponsiveContainer></div></div>
      <div className="card p-4"><div className="mb-2 font-medium">Investment Mix</div><div className="h-64"><ResponsiveContainer width="100%" height="100%">
        <PieChart><Pie data={byCategory} dataKey="total_spent" nameKey="category" outerRadius={100}>{byCategory.map((_,i)=>(<Cell key={i} fill={['#1E3A8A','#D4AF37','#9CA3AF','#10B981'][i%4]}/>))}</Pie></PieChart>
      </ResponsiveContainer></div></div>
    </div>
    <footer className="mt-6 text-center text-xs text-silver/70">“Let’s grow together. Let’s learn how to communicate without commands.”</footer>
  </div>);
}
