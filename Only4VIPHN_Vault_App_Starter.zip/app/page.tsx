
'use client';
import Link from 'next/link'; import { useEffect, useState } from 'react'; import { supabase } from '@/lib/supabase'; import { currency } from '@/lib/util';
type Item={id:string;sku:string|null;title:string;category:string;artist_brand:string|null;est_value:number|null;cover_thumb:string|null};
export default function Home(){
  const [items,setItems]=useState<Item[]>([]); const [loading,setLoading]=useState(true);
  useEffect(()=>{(async()=>{const {data,error}=await supabase.from('items_view').select('*').limit(12); if(!error)setItems(data as any); setLoading(false);})();},[]);
  return (<div><header className="text-center mb-6"><h1 className="text-2xl md:text-3xl font-semibold text-gold">Only4VIPHN</h1><p className="text-silver/90 -mt-1">The Private Collector’s Vault</p></header>
    <section className="grid grid-cols-2 md:grid-cols-4 gap-4">{loading&&Array.from({length:8}).map((_,i)=>(<div key={i} className="card aspect-square animate-pulse" />))}
      {!loading&&items.map(it=> (<Link key={it.id} href={`/item/${it.id}`} className="card overflow-hidden shadow-glow hover:shadow-lg transition">
        <div className="aspect-square bg-ink/60 bg-center bg-cover" style={{backgroundImage:`url(${it.cover_thumb||''})`}}/>
        <div className="p-3"><div className="text-sm text-silver/80">{it.category}</div><div className="font-medium">{it.title}</div><div className="text-emerald">{currency(it.est_value||0)}</div></div>
      </Link>))}
    </section>
    <footer className="mt-6 text-center text-xs text-silver/70">“Let’s grow together. Let’s learn how to communicate without commands.”</footer></div>);
}
