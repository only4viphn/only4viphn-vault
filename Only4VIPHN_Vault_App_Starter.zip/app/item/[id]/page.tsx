
'use client';
import { useParams } from 'next/navigation'; import { useEffect, useState } from 'react'; import { supabase } from '@/lib/supabase'; import { currency } from '@/lib/util'; import Link from 'next/link';
type Photo={id:string;thumb_url:string|null;original_url:string|null}; type Item={id:string;sku:string|null;title:string;category:string;artist_brand:string|null;condition:string|null;location:string|null;purchase_price:number|null;est_value:number|null;story:string|null};
export default function ItemPage(){const {id}=useParams<{id:string}>(); const [item,setItem]=useState<Item|null>(null); const [photos,setPhotos]=useState<Photo[]>([]);
  useEffect(()=>{(async()=>{const [{data:itemData},{data:photoData}]=await Promise.all([supabase.from('items').select('*').eq('id',id).single(),supabase.from('photos').select('*').eq('item_id',id).order('order',{ascending:true}),]); setItem(itemData as any); setPhotos((photoData||[]) as any);})();},[id]);
  if(!item) return <div>Loading…</div>;
  return (<div><Link href="/" className="text-silver/70 hover:text-silver">← Back</Link><div className="grid md:grid-cols-2 gap-6 mt-3">
    <div className="card overflow-hidden"><div className="aspect-square bg-center bg-cover" style={{backgroundImage:`url(${photos[0]?.original_url||''})`}}/>
      <div className="p-3 grid grid-cols-4 gap-2">{photos.slice(0,8).map(p=>(<div key={p.id} className="aspect-square bg-cover bg-center rounded" style={{backgroundImage:`url(${p.thumb_url||p.original_url||''})`}}/>))}</div></div>
    <div className="card p-4"><h2 className="text-xl font-semibold text-gold">{item.title}</h2><div className="text-silver/80">{item.artist_brand||'—'}</div>
      <div className="mt-2 grid grid-cols-2 gap-2 text-sm"><div><span className="text-silver/70">Category:</span> {item.category}</div><div><span className="text-silver/70">Condition:</span> {item.condition||'—'}</div>
      <div><span className="text-silver/70">Cost:</span> {currency(item.purchase_price)}</div><div><span className="text-silver/70">Est. Value:</span> {currency(item.est_value)}</div><div><span className="text-silver/70">Location:</span> {item.location||'—'}</div></div>
      <p className="mt-3 text-sm leading-relaxed">{item.story||'—'}</p>
      <div className="mt-4 flex gap-3"><a className="px-4 py-2 rounded-lg bg-emerald text-ink font-semibold shadow-glow">Ask Sophia</a><a className="px-4 py-2 rounded-lg border border-silver/30">Add Photo</a></div></div>
  </div></div>);
}
