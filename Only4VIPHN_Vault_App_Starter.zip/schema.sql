
create extension if not exists pgcrypto;
create table if not exists items (
  id uuid primary key default gen_random_uuid(),
  sku text,
  title text not null,
  category text not null,
  artist_brand text,
  condition text,
  location text,
  purchase_price numeric,
  est_value numeric,
  status text default 'ready',
  story text,
  found_date date,
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);
create table if not exists photos (
  id uuid primary key default gen_random_uuid(),
  item_id uuid references items(id) on delete cascade,
  original_url text,
  thumb_url text,
  angle text,
  "order" int default 0,
  created_at timestamptz default now()
);
create or replace view items_view as
select i.*, p.thumb_url as cover_thumb
from items i
left join lateral (
  select thumb_url from photos p where p.item_id=i.id order by p."order" asc, p.created_at asc limit 1
) p on true;
create or replace view category_summary as
select category, count(*) as items, coalesce(sum(purchase_price),0) as total_spent, coalesce(sum(est_value),0) as total_value
from items group by category order by category;
create or replace function vault_summary()
returns table(total_items bigint, total_invested numeric, total_value numeric)
language sql security definer as $$
  select count(*), coalesce(sum(purchase_price),0), coalesce(sum(est_value),0) from items;
$$;
alter table items enable row level security;
alter table photos enable row level security;
create policy "read items" on items for select using (true);
create policy "insert items" on items for insert with check (true);
create policy "update items" on items for update using (true);
create policy "read photos" on photos for select using (true);
create policy "insert photos" on photos for insert with check (true);
